import 'dictamen.dart';
import 'inspeccion.dart';

/// Colección de inspecciones. Invariante: no se registran lotes repetidos
/// y la lista interna nunca se expone para modificación.
class ControlCalidad {
  final List<Inspeccion> _inspecciones = [];

  void registrar(Inspeccion inspeccion) {
    for (final i in _inspecciones) {
      if (i.lote.codigo == inspeccion.lote.codigo) {
        throw StateError('El lote ${inspeccion.lote.codigo} ya fue inspeccionado.');
      }
    }
    _inspecciones.add(inspeccion);
  }

  int contar(Dictamen dictamen) =>
      _inspecciones.where((i) => i.dictamen == dictamen).length;

  // Solo lectura
  List<Inspeccion> get inspecciones => List.unmodifiable(_inspecciones);
}
