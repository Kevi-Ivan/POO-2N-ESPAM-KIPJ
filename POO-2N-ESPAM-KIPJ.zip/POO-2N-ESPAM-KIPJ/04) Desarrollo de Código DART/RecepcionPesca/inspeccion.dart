import 'dictamen.dart';
import 'lote_atun.dart';

/// Inspección de calidad de un lote (clase de negocio con la invariante principal).
/// Invariante: solo se aprueba con temperatura <= -18 °C e histamina <= 100 ppm;
/// un dictamen ya emitido no puede modificarse.
class Inspeccion {
  static const double temperaturaMaxima = -18.0;
  static const double histaminaMaxima = 100.0;

  final LoteAtun _lote;
  final String _inspector;
  final double _temperatura;
  final double _tvn;
  final double _histaminaPpm;
  Dictamen _dictamen = Dictamen.PENDIENTE;
  String _observacion = 'Pendiente de dictamen';

  // Constructor canónico: valida todas las entradas
  Inspeccion(LoteAtun lote, String inspector, double temperatura, double tvn,
      double histaminaPpm)
      : _lote = lote,
        _inspector = _textoNoVacio(
            inspector, 'El inspector no puede ser nulo ni vacío.'),
        _temperatura = temperatura,
        _histaminaPpm = _noNegativo(
            histaminaPpm, 'La histamina no puede ser negativa.'),
        _tvn = _noNegativo(tvn, 'El TVN no puede ser negativo.');

  // Equivalente al constructor de 4 parámetros de Java (sin TVN medido)
  Inspeccion.sinTvn(
      LoteAtun lote, String inspector, double temperatura, double histaminaPpm)
      : this(lote, inspector, temperatura, 0.0, histaminaPpm);

  static String _textoNoVacio(String valor, String mensaje) {
    if (valor.trim().isEmpty) throw ArgumentError(mensaje);
    return valor.trim();
  }

  static double _noNegativo(double valor, String mensaje) {
    if (valor < 0) throw ArgumentError(mensaje);
    return valor;
  }

  bool cumpleNorma() =>
      _temperatura <= temperaturaMaxima && _histaminaPpm <= histaminaMaxima;

  String motivoIncumplimiento() {
    if (_temperatura > temperaturaMaxima) {
      return 'temperatura $_temperatura °C supera el máximo de ${temperaturaMaxima.toInt()} °C';
    }
    if (_histaminaPpm > histaminaMaxima) {
      return 'histamina ${_histaminaPpm.toInt()} ppm supera el máximo de ${histaminaMaxima.toInt()} ppm';
    }
    return 'cumple la norma';
  }

  void _verificarPendiente() {
    if (_dictamen != Dictamen.PENDIENTE) {
      throw StateError(
          'La inspección del ${_lote.codigo} ya fue dictaminada (${_dictamen.name}) y no puede modificarse.');
    }
  }

  void aprobar() {
    _verificarPendiente();
    if (!cumpleNorma()) {
      throw StateError(
          'No se puede aprobar el ${_lote.codigo}: ${motivoIncumplimiento()}');
    }
    _dictamen = Dictamen.APROBADO;
    _observacion = 'Cumple temperatura e histamina';
  }

  void rechazar(String motivo) {
    _verificarPendiente();
    if (motivo.trim().isEmpty) {
      throw ArgumentError('El rechazo requiere un motivo.');
    }
    _dictamen = Dictamen.RECHAZADO;
    _observacion = motivo.trim();
  }

  // Emite el dictamen automáticamente según la norma
  void dictaminar() {
    if (cumpleNorma()) {
      aprobar();
    } else {
      rechazar(motivoIncumplimiento());
    }
  }

  LoteAtun get lote => _lote;
  String get inspector => _inspector;
  double get temperatura => _temperatura;
  double get tvn => _tvn;
  double get histaminaPpm => _histaminaPpm;
  Dictamen get dictamen => _dictamen;
  String get observacion => _observacion;

  @override
  String toString() =>
      '${_lote.codigo} | $_temperatura °C | ${_histaminaPpm.toInt()} ppm | ${_dictamen.name} ($_observacion)';
}
