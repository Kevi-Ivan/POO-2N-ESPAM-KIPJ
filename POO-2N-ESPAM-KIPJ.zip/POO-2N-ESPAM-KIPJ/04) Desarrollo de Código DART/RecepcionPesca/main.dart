import 'control_calidad.dart';
import 'dictamen.dart';
import 'inspeccion.dart';
import 'lote_atun.dart';

void main() {
  print('=== 1. CONSTRUCTORES SOBRECARGADOS ===');
  final def = LoteAtun.porDefecto();
  final l1 = LoteAtun('L-001', 'Yellowfin', 1250.5, 'Pesquera Manta');
  final l2 = LoteAtun('L-002', 'Skipjack', 980.0, 'Flota Pacífico');
  final l3 = LoteAtun.sinProveedor('L-003', 'Bigeye', 1100.0);
  print(def);
  print(l1);
  print(l2);
  print(l3);

  final control = ControlCalidad();
  final i1 = Inspeccion.sinTvn(l1, 'Ing. Carla Mera', -20.5, 45);
  final i2 = Inspeccion.sinTvn(l2, 'Ing. Carla Mera', -12.0, 40);
  final i3 = Inspeccion(l3, 'Ing. Carla Mera', -19.0, 22.5, 180);
  control.registrar(i1);
  control.registrar(i2);
  control.registrar(i3);

  print('\n=== 2. CASO VÁLIDO (aceptado) ===');
  i1.aprobar();
  print(i1);

  print('\n=== 3. CASOS INVÁLIDOS (rechazados por la invariante) ===');
  intentar(() => i2.aprobar());
  i2.dictaminar();
  print(i2);
  i3.dictaminar();
  print(i3);

  print('\n=== 4. OTROS DATOS INCORRECTOS ===');
  intentar(() => LoteAtun('L-004', 'Albacora', -5, 'Flota Sur'));
  intentar(() => LoteAtun('', 'Albacora', 500, 'Flota Sur'));
  intentar(() => Inspeccion.sinTvn(l1, 'Ing. Carla Mera', -20, -3));
  intentar(() => i3.aprobar());
  intentar(() => control.registrar(Inspeccion.sinTvn(l1, 'Ing. Pedro Loor', -20, 10)));
  intentar(() => control.inspecciones.clear());

  print('\n=== 5. RESUMEN DEL MÓDULO ===');
  print('Aprobados: ${control.contar(Dictamen.APROBADO)}');
  print('Rechazados: ${control.contar(Dictamen.RECHAZADO)}');
  print('Pendientes: ${control.contar(Dictamen.PENDIENTE)}');
}

void intentar(void Function() accion) {
  try {
    accion();
    print('[SIN ERROR]');
  } on ArgumentError catch (e) {
    print('[REGLA ACTIVADA] ${e.message}');
  } on StateError catch (e) {
    print('[REGLA ACTIVADA] ${e.message}');
  } on UnsupportedError {
    print('[REGLA ACTIVADA] La lista de inspecciones es de solo lectura.');
  }
}
