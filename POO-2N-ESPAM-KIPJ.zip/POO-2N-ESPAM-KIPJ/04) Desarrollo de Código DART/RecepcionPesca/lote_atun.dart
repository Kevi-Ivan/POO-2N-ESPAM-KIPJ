/// Lote de atún recibido de un barco.
/// Invariantes: código, especie y proveedor no vacíos; peso mayor que 0.
/// Atributos `final` y privados (_), sin setters.
class LoteAtun {
  final String _codigo;
  final String _especie;
  final double _pesoKg;
  final String _proveedor;

  // Constructor canónico: único que valida y asigna (Fail-Fast)
  LoteAtun(String codigo, String especie, double pesoKg, String proveedor)
      : _codigo = _texto(codigo, 'El código del lote no puede ser nulo ni vacío.')
            .toUpperCase(),
        _especie = _texto(especie, 'La especie no puede ser nula ni vacía.'),
        _proveedor =
            _texto(proveedor, 'El proveedor no puede ser nulo ni vacío.'),
        _pesoKg = _positivo(pesoKg, 'El peso del lote debe ser mayor que 0 kg.');

  // Equivalente al constructor por defecto de Java
  LoteAtun.porDefecto() : this('LOTE-DEF-001', 'Albacora', 100.0, 'Proveedor no registrado');

  // Equivalente al constructor sobrecargado de 3 parámetros de Java
  LoteAtun.sinProveedor(String codigo, String especie, double pesoKg)
      : this(codigo, especie, pesoKg, 'Proveedor no registrado');

  static String _texto(String valor, String mensaje) {
    if (valor.trim().isEmpty) throw ArgumentError(mensaje);
    return valor.trim();
  }

  static double _positivo(double valor, String mensaje) {
    if (valor <= 0) throw ArgumentError(mensaje);
    return valor;
  }

  String get codigo => _codigo;
  String get especie => _especie;
  double get pesoKg => _pesoKg;
  String get proveedor => _proveedor;

  @override
  String toString() => 'Lote $_codigo | $_especie | $_pesoKg kg | $_proveedor';
}
