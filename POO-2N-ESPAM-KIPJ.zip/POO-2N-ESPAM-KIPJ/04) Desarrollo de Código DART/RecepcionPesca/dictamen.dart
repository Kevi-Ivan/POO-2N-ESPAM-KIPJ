/// Estados posibles del dictamen de una inspección de calidad.
enum Dictamen { PENDIENTE, APROBADO, RECHAZADO }
