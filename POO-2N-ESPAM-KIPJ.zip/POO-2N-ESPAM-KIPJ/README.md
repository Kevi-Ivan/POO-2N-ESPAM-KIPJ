# POO-2N-ESPAM-KIPJ

Portafolio Técnico de la Unidad 1 — Programación Orientada a Objetos (CDS-0201), ESPAM MFL.
Estudiante: Kevin Ivan Peralta Jaime · Caso: Planta procesadora de atún — Módulo de Control de Calidad.

## Estructura
- `0) Documento/` — PortafolioUnidad1POO-KIPJ.pdf
- `01) Análisis del Problema/` — Analisisdelproblema.jpg, MetodoSCQA.jpg
- `02) Diagrama de clases UML/` — DiagramaRecepcionDePesca.drawio (editable) y .jpg
- `03) Desarrollo de Código JAVA/RecepcionPesca/src/` — Main, LoteAtun, Inspeccion, ControlCalidad, Dictamen
- `04) Desarrollo de Código DART/RecepcionPesca/` — migración a Dart

## Ejecutar
Java: `javac *.java` y luego `java Main` (dentro de `src/`).
Dart: `dart run main.dart` (dentro de `RecepcionPesca/`).

## Invariante principal
Un lote solo se APRUEBA si temperatura ≤ -18 °C e histamina ≤ 100 ppm; un dictamen emitido no se modifica.
