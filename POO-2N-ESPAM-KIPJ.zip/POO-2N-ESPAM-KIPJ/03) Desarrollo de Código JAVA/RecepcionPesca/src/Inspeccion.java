/**
 * Inspección de calidad de un lote (clase de negocio con la invariante principal).
 * Invariante: un lote solo puede quedar APROBADO si temperatura de núcleo <= -18 °C
 * e histamina <= 100 ppm; un dictamen ya emitido no puede modificarse.
 */
public class Inspeccion {
    public static final double TEMPERATURA_MAXIMA = -18.0;
    public static final double HISTAMINA_MAXIMA = 100.0;

    private final LoteAtun lote;
    private final String inspector;
    private final double temperatura;
    private final double tvn;
    private final double histaminaPpm;
    private Dictamen dictamen;
    private String observacion;

    // Constructor 1: sin TVN medido (valor 0.0)
    public Inspeccion(LoteAtun lote, String inspector, double temperatura, double histaminaPpm) {
        this(lote, inspector, temperatura, 0.0, histaminaPpm);
    }

    // Constructor 2: canónico, valida todas las entradas
    public Inspeccion(LoteAtun lote, String inspector, double temperatura, double tvn, double histaminaPpm) {
        if (lote == null)
            throw new IllegalArgumentException("La inspección requiere un lote.");
        if (inspector == null || inspector.trim().isEmpty())
            throw new IllegalArgumentException("El inspector no puede ser nulo ni vacío.");
        if (histaminaPpm < 0)
            throw new IllegalArgumentException("La histamina no puede ser negativa.");
        if (tvn < 0)
            throw new IllegalArgumentException("El TVN no puede ser negativo.");
        this.lote = lote;
        this.inspector = inspector.trim();
        this.temperatura = temperatura;
        this.tvn = tvn;
        this.histaminaPpm = histaminaPpm;
        this.dictamen = Dictamen.PENDIENTE;
        this.observacion = "Pendiente de dictamen";
    }

    public boolean cumpleNorma() {
        return temperatura <= TEMPERATURA_MAXIMA && histaminaPpm <= HISTAMINA_MAXIMA;
    }

    public String motivoIncumplimiento() {
        if (temperatura > TEMPERATURA_MAXIMA)
            return "temperatura " + temperatura + " °C supera el máximo de " + (int) TEMPERATURA_MAXIMA + " °C";
        if (histaminaPpm > HISTAMINA_MAXIMA)
            return "histamina " + (int) histaminaPpm + " ppm supera el máximo de " + (int) HISTAMINA_MAXIMA + " ppm";
        return "cumple la norma";
    }

    private void verificarPendiente() {
        if (dictamen != Dictamen.PENDIENTE)
            throw new IllegalStateException("La inspección del " + lote.getCodigo()
                    + " ya fue dictaminada (" + dictamen + ") y no puede modificarse.");
    }

    public void aprobar() {
        verificarPendiente();
        if (!cumpleNorma())
            throw new IllegalStateException("No se puede aprobar el " + lote.getCodigo() + ": " + motivoIncumplimiento());
        dictamen = Dictamen.APROBADO;
        observacion = "Cumple temperatura e histamina";
    }

    public void rechazar(String motivo) {
        verificarPendiente();
        if (motivo == null || motivo.trim().isEmpty())
            throw new IllegalArgumentException("El rechazo requiere un motivo.");
        dictamen = Dictamen.RECHAZADO;
        observacion = motivo.trim();
    }

    // Emite el dictamen automáticamente según la norma
    public void dictaminar() {
        if (cumpleNorma()) aprobar();
        else rechazar(motivoIncumplimiento());
    }

    public LoteAtun getLote() { return lote; }
    public String getInspector() { return inspector; }
    public double getTemperatura() { return temperatura; }
    public double getTvn() { return tvn; }
    public double getHistaminaPpm() { return histaminaPpm; }
    public Dictamen getDictamen() { return dictamen; }
    public String getObservacion() { return observacion; }

    @Override
    public String toString() {
        return lote.getCodigo() + " | " + temperatura + " °C | " + (int) histaminaPpm + " ppm | "
                + dictamen + " (" + observacion + ")";
    }
}
