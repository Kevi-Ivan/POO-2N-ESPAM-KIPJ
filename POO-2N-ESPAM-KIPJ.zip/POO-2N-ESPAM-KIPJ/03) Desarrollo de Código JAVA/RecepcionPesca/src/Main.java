public class Main {
    public static void main(String[] args) {
        System.out.println("=== 1. CONSTRUCTORES SOBRECARGADOS ===");
        LoteAtun def = new LoteAtun();
        LoteAtun l1 = new LoteAtun("L-001", "Yellowfin", 1250.5, "Pesquera Manta");
        LoteAtun l2 = new LoteAtun("L-002", "Skipjack", 980.0, "Flota Pacífico");
        LoteAtun l3 = new LoteAtun("L-003", "Bigeye", 1100.0);
        System.out.println(def);
        System.out.println(l1);
        System.out.println(l2);
        System.out.println(l3);

        ControlCalidad control = new ControlCalidad();
        Inspeccion i1 = new Inspeccion(l1, "Ing. Carla Mera", -20.5, 45);
        Inspeccion i2 = new Inspeccion(l2, "Ing. Carla Mera", -12.0, 40);
        Inspeccion i3 = new Inspeccion(l3, "Ing. Carla Mera", -19.0, 22.5, 180);
        control.registrar(i1);
        control.registrar(i2);
        control.registrar(i3);

        System.out.println("\n=== 2. CASO VÁLIDO (aceptado) ===");
        i1.aprobar();
        System.out.println(i1);

        System.out.println("\n=== 3. CASOS INVÁLIDOS (rechazados por la invariante) ===");
        intentar(i2::aprobar);
        i2.dictaminar();
        System.out.println(i2);
        i3.dictaminar();
        System.out.println(i3);

        System.out.println("\n=== 4. OTROS DATOS INCORRECTOS ===");
        intentar(() -> new LoteAtun("L-004", "Albacora", -5, "Flota Sur"));
        intentar(() -> new LoteAtun("", "Albacora", 500, "Flota Sur"));
        intentar(() -> new Inspeccion(l1, "Ing. Carla Mera", -20, -3));
        intentar(() -> i3.aprobar());
        intentar(() -> control.registrar(new Inspeccion(l1, "Ing. Pedro Loor", -20, 10)));
        intentar(() -> control.getInspecciones().clear());

        System.out.println("\n=== 5. RESUMEN DEL MÓDULO ===");
        System.out.println("Aprobados: " + control.contar(Dictamen.APROBADO));
        System.out.println("Rechazados: " + control.contar(Dictamen.RECHAZADO));
        System.out.println("Pendientes: " + control.contar(Dictamen.PENDIENTE));
    }

    private static void intentar(Runnable accion) {
        try {
            accion.run();
            System.out.println("[SIN ERROR]");
        } catch (IllegalArgumentException | IllegalStateException | UnsupportedOperationException e) {
            String mensaje = e instanceof UnsupportedOperationException
                    ? "La lista de inspecciones es de solo lectura." : e.getMessage();
            System.out.println("[REGLA ACTIVADA] " + mensaje);
        }
    }
}
