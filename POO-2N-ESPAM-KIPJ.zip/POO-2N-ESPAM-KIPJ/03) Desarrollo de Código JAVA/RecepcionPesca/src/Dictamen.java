/** Estados posibles del dictamen de una inspección de calidad. */
public enum Dictamen {
    PENDIENTE, APROBADO, RECHAZADO
}
