import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Colección de inspecciones. Invariante: no se registran lotes repetidos
 * y la lista interna nunca se expone para modificación.
 */
public class ControlCalidad {
    private final List<Inspeccion> inspecciones = new ArrayList<>();

    public void registrar(Inspeccion inspeccion) {
        if (inspeccion == null)
            throw new IllegalArgumentException("No se puede registrar una inspección nula.");
        for (Inspeccion i : inspecciones) {
            if (i.getLote().getCodigo().equals(inspeccion.getLote().getCodigo()))
                throw new IllegalStateException("El lote " + inspeccion.getLote().getCodigo() + " ya fue inspeccionado.");
        }
        inspecciones.add(inspeccion);
    }

    public int contar(Dictamen dictamen) {
        int total = 0;
        for (Inspeccion i : inspecciones)
            if (i.getDictamen() == dictamen) total++;
        return total;
    }

    // Solo lectura
    public List<Inspeccion> getInspecciones() {
        return Collections.unmodifiableList(inspecciones);
    }
}
