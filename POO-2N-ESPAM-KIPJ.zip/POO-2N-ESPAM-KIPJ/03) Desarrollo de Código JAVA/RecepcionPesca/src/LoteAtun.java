/**
 * Lote de atún recibido de un barco.
 * Invariantes de clase: código, especie y proveedor no vacíos; peso mayor que 0.
 * Todos los atributos son private final y no existen setters.
 */
public class LoteAtun {
    private final String codigo;
    private final String especie;
    private final double pesoKg;
    private final String proveedor;

    // Constructor 1: por defecto (valores predeterminados)
    public LoteAtun() {
        this("LOTE-DEF-001", "Albacora", 100.0);
    }

    // Constructor 2: sobrecargado, proveedor por defecto
    public LoteAtun(String codigo, String especie, double pesoKg) {
        this(codigo, especie, pesoKg, "Proveedor no registrado");
    }

    // Constructor 3: canónico, único que valida y asigna (Fail-Fast)
    public LoteAtun(String codigo, String especie, double pesoKg, String proveedor) {
        if (codigo == null || codigo.trim().isEmpty())
            throw new IllegalArgumentException("El código del lote no puede ser nulo ni vacío.");
        if (especie == null || especie.trim().isEmpty())
            throw new IllegalArgumentException("La especie no puede ser nula ni vacía.");
        if (proveedor == null || proveedor.trim().isEmpty())
            throw new IllegalArgumentException("El proveedor no puede ser nulo ni vacío.");
        if (pesoKg <= 0)
            throw new IllegalArgumentException("El peso del lote debe ser mayor que 0 kg.");
        this.codigo = codigo.trim().toUpperCase();
        this.especie = especie.trim();
        this.pesoKg = pesoKg;
        this.proveedor = proveedor.trim();
    }

    public String getCodigo() { return codigo; }
    public String getEspecie() { return especie; }
    public double getPesoKg() { return pesoKg; }
    public String getProveedor() { return proveedor; }

    @Override
    public String toString() {
        return "Lote " + codigo + " | " + especie + " | " + pesoKg + " kg | " + proveedor;
    }
}
